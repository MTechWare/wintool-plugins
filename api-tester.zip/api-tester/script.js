// Use a timeout to ensure all DOM elements are loaded before the script runs.
setTimeout(() => {
    const pluginId = 'api-tester';

    // --- Element References ---
    const testSysInfoBtn = document.getElementById('test-sysinfo');
    const outputSysInfo = document.getElementById('output-sysinfo');

    const testScriptBtn = document.getElementById('test-script');
    const outputScript = document.getElementById('output-script');

    const testNotifySuccessBtn = document.getElementById('test-notify-success');
    const testNotifyWarningBtn = document.getElementById('test-notify-warning');
    const testNotifyErrorBtn = document.getElementById('test-notify-error');
    const outputNotify = document.getElementById('output-notify');

    const testStorageSaveBtn = document.getElementById('test-storage-save');
    const testStorageLoadBtn = document.getElementById('test-storage-load');
    const outputStorage = document.getElementById('output-storage');

    const testDialogOpenBtn = document.getElementById('test-dialog-open');
    const testDialogSaveBtn = document.getElementById('test-dialog-save');
    const outputDialog = document.getElementById('output-dialog');

    const outputTabs = document.getElementById('output-tabs');

    const testInvokeBackendBtn = document.getElementById('test-invoke-backend');
    const outputInvoke = document.getElementById('output-invoke');

    const testBackendLibBtn = document.getElementById('test-backend-lib');
    const outputBackendLib = document.getElementById('output-backend-lib');

    // --- API Test Implementations ---

    // 1. getSystemInfo
    testSysInfoBtn.addEventListener('click', async () => {
        outputSysInfo.textContent = 'Loading...';
        try {
            const cpuInfo = await window.wintoolAPI.getSystemInfo('cpu');
            outputSysInfo.textContent = `CPU Brand: ${cpuInfo.brand}\nCores: ${cpuInfo.cores}`;
        } catch (err) {
            outputSysInfo.textContent = `Error: ${err.message}`;
        }
    });

    // 2. runPluginScript
    testScriptBtn.addEventListener('click', async () => {
        outputScript.textContent = 'Running...';
        try {
            const result = await window.wintoolAPI.runPluginScript(pluginId, 'test-script.ps1');
            outputScript.textContent = result;
        } catch (err) {
            outputScript.textContent = `Error: ${err.message}`;
        }
    });

    // 3. showNotification
    testNotifySuccessBtn.addEventListener('click', () => {
        outputNotify.textContent = "Showing 'success' notification.";
        window.wintoolAPI.showNotification({
            title: 'Success!',
            body: 'This is a success notification from a plugin.',
            type: 'success'
        });
    });
    testNotifyWarningBtn.addEventListener('click', () => {
        outputNotify.textContent = "Showing 'warning' notification.";
        window.wintoolAPI.showNotification({
            title: 'Warning!',
            body: 'This is a warning notification from a plugin.',
            type: 'warning'
        });
    });
    testNotifyErrorBtn.addEventListener('click', () => {
        outputNotify.textContent = "Showing 'error' notification.";
        window.wintoolAPI.showNotification({
            title: 'Error!',
            body: 'This is an error notification from a plugin.',
            type: 'error'
        });
    });

    // 4. storage
    let launchCount = 0;
    testStorageSaveBtn.addEventListener('click', async () => {
        try {
            const currentCount = await window.wintoolAPI.storage.get(pluginId, 'launchCount') || 0;
            const newCount = currentCount + 1;
            await window.wintoolAPI.storage.set(pluginId, 'launchCount', newCount);
            outputStorage.textContent = `Save successful. New count is ${newCount}.`;
        } catch(err) {
            outputStorage.textContent = `Error: ${err.message}`;
        }
    });
    testStorageLoadBtn.addEventListener('click', async () => {
        try {
            const savedCount = await window.wintoolAPI.storage.get(pluginId, 'launchCount') || 0;
            outputStorage.textContent = `Loaded count: ${savedCount}`;
        } catch(err) {
            outputStorage.textContent = `Error: ${err.message}`;
        }
    });

    // 5. dialog
    testDialogOpenBtn.addEventListener('click', async () => {
        outputDialog.textContent = 'Opening dialog...';
        try {
            const result = await window.wintoolAPI.dialog.showOpenDialog({
                title: 'Plugin File Open',
                filters: [{ name: 'Text Files', extensions: ['txt'] }]
            });
            if (result.canceled) {
                outputDialog.textContent = 'Dialog canceled.';
            } else {
                outputDialog.textContent = `File opened: ${result.file.path}\n\nContent:\n${result.file.content.substring(0, 100)}...`;
            }
        } catch (err) {
            outputDialog.textContent = `Error: ${err.message}`;
        }
    });
    testDialogSaveBtn.addEventListener('click', async () => {
        outputDialog.textContent = 'Opening dialog...';
        try {
            const contentToSave = `This file was saved by the API Tester plugin at ${new Date().toISOString()}`;
            const result = await window.wintoolAPI.dialog.showSaveDialog({
                title: 'Plugin File Save',
                defaultPath: 'api-tester-save.txt'
            }, contentToSave);
            
            if (result.canceled) {
                outputDialog.textContent = 'Dialog canceled.';
            } else {
                outputDialog.textContent = `File saved to: ${result.path}`;
            }
        } catch (err) {
            outputDialog.textContent = `Error: ${err.message}`;
        }
    });

    // 6. tabs.on('tab-switched')
    function handleTabSwitch(event) {
        const { newTabId, previousTabId } = event.detail;
        outputTabs.textContent = `Tab switched!\nFrom: ${previousTabId}\nTo: ${newTabId}`;
    }
    window.wintoolAPI.tabs.on('tab-switched', handleTabSwitch);

    // 7. invoke (backend)
    testInvokeBackendBtn.addEventListener('click', async () => {
        outputInvoke.textContent = 'Calling backend...';
        try {
            const result = await window.wintoolAPI.invoke(pluginId, 'getBackendInfo');
            outputInvoke.textContent = JSON.stringify(result, null, 2);
        } catch (err) {
            outputInvoke.textContent = `Error: ${err.message}`;
        }
    });

    // 8. Backend library usage
    testBackendLibBtn.addEventListener('click', async () => {
        outputBackendLib.textContent = 'Fetching weather...';
        try {
            const result = await window.wintoolAPI.invoke(pluginId, 'getWeather');
            outputBackendLib.textContent = result;
        } catch (err) {
            outputBackendLib.textContent = `Error: ${err.message}`;
        }
    });

    // Mark the plugin as ready for the tab loader.
    if (window.markTabAsReady) {
        window.markTabAsReady(pluginId);
    }

}, 0);
