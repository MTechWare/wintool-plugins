/**
 * This is the backend script for the API Tester plugin.
 * It runs in the main process and can use Node.js modules.
 */

// We can use require here because we're in the main process.
const os = require('os');
const axios = require('axios'); // Import the newly installed library

function initialize(backendApi) {
    console.log('Initializing API Tester backend...');

    /**
     * Registers a handler named 'getBackendInfo'.
     * When the frontend calls wintoolAPI.invoke('api-tester', 'getBackendInfo'), this function will run.
     * @returns {Promise<object>} An object with some information from the backend.
     */
    backendApi.registerHandler('getBackendInfo', async () => {
        // We can perform Node.js operations here.
        const userInfo = os.userInfo();
        const arch = os.arch();

        // We can also use parts of the backendApi passed to us.
        const store = await backendApi.getStore();
        store.set('api_tester_last_backend_call', new Date().toISOString());

        return {
            message: 'This message came from the backend.js file!',
            username: userInfo.username,
            architecture: arch,
            lastCalled: await store.get('api_tester_last_backend_call')
        };
    });

    /**
     * Registers a handler that uses a third-party library (axios) to fetch data from a public API.
     * @returns {Promise<string>} A string describing the weather in a random city.
     */
    backendApi.registerHandler('getWeather', async () => {
        try {
            const cities = ['London', 'Paris', 'Tokyo', 'New York', 'Sydney'];
            const randomCity = cities[Math.floor(Math.random() * cities.length)];
            
            // Use wttr.in, a simple text-based weather API that's great for testing.
            const response = await axios.get(`https://wttr.in/${encodeURIComponent(randomCity)}?format=j1`);
            
            const weatherData = response.data;
            const currentCondition = weatherData.current_condition[0];

            return `The weather in ${weatherData.nearest_area[0].areaName[0].value} is: ${currentCondition.weatherDesc[0].value}, with a temperature of ${currentCondition.temp_C}°C.`;

        } catch (error) {
            console.error("Weather API call failed:", error.message);
            // Return a user-friendly error message if the API call fails
            throw new Error('Could not fetch weather data. Please check the internet connection.');
        }
    });
}

module.exports = { initialize };
