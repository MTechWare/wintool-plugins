
/**
 * WinTool Plugin Backend
 *
 * This file runs in the main Node.js process, providing secure access to
 * system resources. It must export an `initialize` function.
 */
module.exports = {
  /**
   * @param {object} api - A secure API provided by WinTool to register handlers.
   *                       - api.registerHandler(name, function)
   */
  initialize: (api) => {
    // Register handlers that can be called from the frontend using `wintoolAPI.invoke()`.
    // This is the primary method for communication between the sandboxed frontend and the secure backend.
    api.registerHandler('ping', () => {
      // This is a simple synchronous handler.
      return 'pong';
    });

    // You can also register asynchronous handlers.
    api.registerHandler('greet', async (name) => {
      return `Hello from the backend, ${name}!`;
    });

    // This handler demonstrates reading a local file from the plugin's directory.
    // This is a reliable, local alternative to network requests.
    api.registerHandler('readSampleFile', async () => {
      try {
        const path = require('path');
        const fs = require('fs').promises;

        // __dirname is the absolute path of the currently executing script (backend.js)
        const samplePath = path.join(__dirname, 'sample.json');
        
        const data = await fs.readFile(samplePath, 'utf8');
        return JSON.parse(data);
      } catch (error) {
        console.error('File read failed:', error.message);
        throw new Error('Failed to read sample.json from the plugin directory.');
      }
    });

    // --- To-Do List Handlers (with NPM package) ---
    // Use the secure api.require to load the dependency from the plugin's node_modules.
    let uuidv4;
    try {
        const uuid = api.require('uuid');
        uuidv4 = uuid.v4;
    } catch (e) {
        console.error("Failed to load 'uuid' package via api.require. Did 'npm install' run correctly for the plugin?");
        // We'll create a fallback function so the plugin doesn't crash, but we'll show an error on the frontend.
        uuidv4 = () => {
          throw new Error("The 'uuid' package is not installed. Check the application logs for npm errors.");
        };
    }
    const TODO_STORAGE_KEY = 'developer-template-todos'; // Use a unique key

    api.registerHandler('getTodos', async () => {
      const store = await api.getStore();
      return store.get(TODO_STORAGE_KEY) || [];
    });

    api.registerHandler('addTodo', async (text) => {
      const store = await api.getStore();
      const todos = store.get(TODO_STORAGE_KEY) || [];
      const newTodo = { id: uuidv4(), text }; // Use the (potentially fallible) uuid function
      todos.push(newTodo);
      await store.set(TODO_STORAGE_KEY, todos);
      return todos;
    });

    api.registerHandler('deleteTodo', async (id) => {
      const store = await api.getStore();
      let todos = store.get(TODO_STORAGE_KEY) || [];
      todos = todos.filter(todo => todo.id !== id);
      await store.set(TODO_STORAGE_KEY, todos);
      return todos;
    });

    // --- Axios Network Request Handler ---
    api.registerHandler('fetchRandomUser', async () => {
      try {
        // The 'axios' instance is pre-configured and provided by the API
        const response = await api.axios.get('https://randomuser.me/api/');
        const user = response.data.results[0];
        return {
          name: `${user.name.first} ${user.name.last}`,
          email: user.email
        };
      } catch (error) {
        console.error('Axios request failed:', error.message);
        // Propagate a user-friendly error to the frontend
        throw new Error(`Failed to fetch data from API. Is the internet connection working?`);
      }
    });
  }
};
