// Developer Template Plugin - Fixed Version with Duplication Prevention
// Use a timeout to ensure all DOM elements are loaded before the script runs.
// This is a good practice to prevent issues with elements not being available yet.
setTimeout(() => {
    // IMPORTANT: This ID must match the plugin's folder name. It's used to
    // namespace storage and identify the plugin for backend calls.
    const pluginId = 'developer-template';
    
    // === DUPLICATION PREVENTION ===
    // Check if this plugin has already been initialized
    const INIT_FLAG = `pluginInitialized_${pluginId}`;
    if (window[INIT_FLAG]) {
        console.log(`${pluginId} already initialized, skipping duplicate initialization...`);
        // Still need to mark as ready for the tab system
        if (window.markTabAsReady) {
            window.markTabAsReady(pluginId);
        }
        return;
    }
    
    // Mark as initialized immediately to prevent race conditions
    window[INIT_FLAG] = true;
    console.log(`Initializing ${pluginId}...`);

    // --- Element References ---
    // Get references to all the buttons and output areas in index.html.
    const testSysInfoBtn = document.getElementById('test-sysinfo');
    const outputSysInfo = document.getElementById('output-sysinfo');

    const testScriptBtn = document.getElementById('test-script');
    const outputScript = document.getElementById('output-script');

    const testNotifySuccessBtn = document.getElementById('test-notify-success');
    const testNotifyWarningBtn = document.getElementById('test-notify-warning');
    const testNotifyErrorBtn = document.getElementById('test-notify-error');
    const outputNotify = document.getElementById('output-notify');

    const testStorageSaveBtn = document.getElementById('test-storage-save');
    const testStorageLoadBtn = document.getElementById('test-storage-load');
    const outputStorage = document.getElementById('output-storage');

    const testDialogOpenBtn = document.getElementById('test-dialog-open');
    const testDialogSaveBtn = document.getElementById('test-dialog-save');
    const outputDialog = document.getElementById('output-dialog');

    const outputTabs = document.getElementById('output-tabs');

    const testInvokeBtn = document.getElementById('test-invoke');
    const outputInvoke = document.getElementById('output-invoke');

    const testBackendFileBtn = document.getElementById('test-backend-file');
    const outputBackendFile = document.getElementById('output-backend-file');

    const testAxiosBtn = document.getElementById('test-axios-request');
    const outputAxios = document.getElementById('output-axios-request');

    // Check if all required elements exist
    const requiredElements = [
        testSysInfoBtn, outputSysInfo, testScriptBtn, outputScript,
        testNotifySuccessBtn, testNotifyWarningBtn, testNotifyErrorBtn, outputNotify,
        testStorageSaveBtn, testStorageLoadBtn, outputStorage,
        testDialogOpenBtn, testDialogSaveBtn, outputDialog,
        outputTabs, testInvokeBtn, outputInvoke,
        testBackendFileBtn, outputBackendFile, testAxiosBtn, outputAxios
    ];

    const missingElements = requiredElements.filter(el => !el);
    if (missingElements.length > 0) {
        console.error(`${pluginId}: Missing required DOM elements. Plugin may not function correctly.`);
    }

    // --- API Test Implementations ---

    // 1. getSystemInfo: Fetches various kinds of system information.
    if (testSysInfoBtn && outputSysInfo) {
        testSysInfoBtn.addEventListener('click', async () => {
            outputSysInfo.textContent = 'Loading...';
            try {
                const cpuInfo = await window.wintoolAPI.getSystemInfo('cpu');
                outputSysInfo.textContent = `CPU Brand: ${cpuInfo.brand}\nCores: ${cpuInfo.cores}`;
            } catch (err) {
                outputSysInfo.textContent = `Error: ${err.message}`;
            }
        });
    }

    // 2. runPluginScript: Executes a PowerShell script located in the plugin's directory.
    // The main process handles this securely, preventing access outside the plugin's folder.
    if (testScriptBtn && outputScript) {
        testScriptBtn.addEventListener('click', async () => {
            outputScript.textContent = 'Running...';
            try {
                const result = await window.wintoolAPI.runPluginScript(pluginId, 'test-script.ps1');
                outputScript.textContent = result;
            } catch (err) {
                outputScript.textContent = `Error: ${err.message}`;
            }
        });
    }

    // 3. showNotification: Displays a native-style notification.
    if (testNotifySuccessBtn) {
        testNotifySuccessBtn.addEventListener('click', () => {
            if (outputNotify) outputNotify.textContent = "Showing 'success' notification.";
            window.wintoolAPI.showNotification({
                title: 'Success!',
                body: 'This is a success notification from a plugin.',
                type: 'success'
            });
        });
    }
    
    if (testNotifyWarningBtn) {
        testNotifyWarningBtn.addEventListener('click', () => {
            if (outputNotify) outputNotify.textContent = "Showing 'warning' notification.";
            window.wintoolAPI.showNotification({
                title: 'Warning!',
                body: 'This is a warning notification from a plugin.',
                type: 'warning'
            });
        });
    }
    
    if (testNotifyErrorBtn) {
        testNotifyErrorBtn.addEventListener('click', () => {
            if (outputNotify) outputNotify.textContent = "Showing 'error' notification.";
            window.wintoolAPI.showNotification({
                title: 'Error!',
                body: 'This is an error notification from a plugin.',
                type: 'error'
            });
        });
    }

    // 4. storage: A namespaced key-value store for plugins to persist settings.
    // Data is stored securely and is unique to this pluginId.
    if (testStorageSaveBtn && outputStorage) {
        testStorageSaveBtn.addEventListener('click', async () => {
            try {
                const currentCount = await window.wintoolAPI.storage.get(pluginId, 'launchCount') || 0;
                const newCount = currentCount + 1;
                await window.wintoolAPI.storage.set(pluginId, 'launchCount', newCount);
                outputStorage.textContent = `Save successful. New count is ${newCount}.`;
            } catch(err) {
                outputStorage.textContent = `Error: ${err.message}`;
            }
        });
    }
    
    if (testStorageLoadBtn && outputStorage) {
        testStorageLoadBtn.addEventListener('click', async () => {
            try {
                const savedCount = await window.wintoolAPI.storage.get(pluginId, 'launchCount') || 0;
                outputStorage.textContent = `Loaded count: ${savedCount}`;
            } catch(err) {
                outputStorage.textContent = `Error: ${err.message}`;
            }
        });
    }

    // 5. dialog: Functions for interacting with the file system via secure dialogs.
    // Plugins cannot access the file system directly and must use these user-mediated functions.
    if (testDialogOpenBtn && outputDialog) {
        testDialogOpenBtn.addEventListener('click', async () => {
            outputDialog.textContent = 'Opening dialog...';
            try {
                const result = await window.wintoolAPI.dialog.showOpenDialog({
                    title: 'Plugin File Open',
                    filters: [{ name: 'Text Files', extensions: ['txt'] }]
                });
                if (result.canceled) {
                    outputDialog.textContent = 'Dialog canceled.';
                } else {
                    outputDialog.textContent = `File opened: ${result.file.path}\n\nContent:\n${result.file.content.substring(0, 100)}...`;
                }
            } catch (err) {
                outputDialog.textContent = `Error: ${err.message}`;
            }
        });
    }
    
    if (testDialogSaveBtn && outputDialog) {
        testDialogSaveBtn.addEventListener('click', async () => {
            outputDialog.textContent = 'Opening dialog...';
            try {
                const contentToSave = `This file was saved by the Developer Template plugin at ${new Date().toISOString()}`;
                const result = await window.wintoolAPI.dialog.showSaveDialog({
                    title: 'Plugin File Save',
                    defaultPath: 'developer-template-save.txt'
                }, contentToSave);

                if (result.canceled) {
                    outputDialog.textContent = 'Dialog canceled.';
                } else {
                    outputDialog.textContent = `File saved to: ${result.path}`;
                }
            } catch (err) {
                outputDialog.textContent = `Error: ${err.message}`;
            }
        });
    }

    // 6. tabs.on/off('tab-switched'): An event system for listening to tab changes.
    if (outputTabs) {
        // Store the handler function so we can reference it for removal
        window[`${pluginId}_tabSwitchHandler`] = function handleTabSwitch(event) {
            const { newTabId, previousTabId } = event.detail;
            outputTabs.textContent = `Tab switched!\nFrom: ${previousTabId}\nTo: ${newTabId}`;
            // The .off() method removes the event listener.
            // This example shows how to make a "one-time" listener.
            window.wintoolAPI.tabs.off('tab-switched', window[`${pluginId}_tabSwitchHandler`]);
            outputTabs.textContent += '\nListener removed.';
        };
        
        window.wintoolAPI.tabs.on('tab-switched', window[`${pluginId}_tabSwitchHandler`]);
    }

    // 7. invoke: Calls a function registered in your plugin's backend.js.
    // This is the primary way to trigger secure, backend operations from the frontend.
    if (testInvokeBtn && outputInvoke) {
        testInvokeBtn.addEventListener('click', async () => {
            outputInvoke.textContent = 'Invoking...';
            try {
                const result = await window.wintoolAPI.invoke(pluginId, 'ping');
                outputInvoke.textContent = `Invoke result: ${result}`;
            } catch (err) {
                outputInvoke.textContent = `Error: ${err.message}`;
            }
        });
    }

    // 8. Advanced invoke: Backend file access with loading state
    if (testBackendFileBtn && outputBackendFile) {
        testBackendFileBtn.addEventListener('click', async () => {
            // --- Loading State: Start ---
            testBackendFileBtn.disabled = true;
            outputBackendFile.textContent = 'Reading file...';
            const spinner = document.createElement('div');
            spinner.className = 'spinner';
            testBackendFileBtn.appendChild(spinner);

            try {
                const result = await window.wintoolAPI.invoke(pluginId, 'readSampleFile');
                // Use JSON.stringify to nicely format the returned object
                outputBackendFile.textContent = JSON.stringify(result, null, 2);
            } catch (err) {
                outputBackendFile.textContent = `Error: ${err.message}`;
            } finally {
                // --- Loading State: End ---
                testBackendFileBtn.disabled = false;
                if (spinner.parentNode) {
                    testBackendFileBtn.removeChild(spinner);
                }
            }
        });
    }

    // 9. Advanced invoke: Backend network request using axios
    if (testAxiosBtn && outputAxios) {
        testAxiosBtn.addEventListener('click', async () => {
            // --- Loading State: Start ---
            testAxiosBtn.disabled = true;
            outputAxios.textContent = 'Fetching data...';
            const spinner = document.createElement('div');
            spinner.className = 'spinner';
            testAxiosBtn.appendChild(spinner);

            try {
                const result = await window.wintoolAPI.invoke(pluginId, 'fetchRandomUser');
                // Use JSON.stringify to nicely format the returned object
                outputAxios.textContent = JSON.stringify(result, null, 2);
            } catch (err) {
                outputAxios.textContent = `Error: ${err.message}`;
            } finally {
                // --- Loading State: End ---
                testAxiosBtn.disabled = false;
                if (spinner.parentNode) {
                    testAxiosBtn.removeChild(spinner);
                }
            }
        });
    }

    // --- To-Do List Example ---
    const todoInput = document.getElementById('todo-input');
    const addTodoBtn = document.getElementById('add-todo-btn');
    const todoList = document.getElementById('todo-list');

    if (todoInput && addTodoBtn && todoList) {
        // Function to render the list of to-do items
        function renderTodos(todos) {
            todoList.innerHTML = '';
            if (!todos || todos.length === 0) {
                todoList.innerHTML = '<li>No tasks yet.</li>';
                return;
            }
            todos.forEach(todo => {
                const li = document.createElement('li');
                li.textContent = todo.text;
                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = 'Delete';
                deleteBtn.className = 'btn btn-danger btn-sm';
                deleteBtn.onclick = async () => {
                    const updatedTodos = await window.wintoolAPI.invoke(pluginId, 'deleteTodo', todo.id);
                    renderTodos(updatedTodos);
                };
                li.appendChild(deleteBtn);
                todoList.appendChild(li);
            });
        }

        // Event listener for the "Add" button
        addTodoBtn.addEventListener('click', async () => {
            const text = todoInput.value.trim();
            if (text) {
                const updatedTodos = await window.wintoolAPI.invoke(pluginId, 'addTodo', text);
                renderTodos(updatedTodos);
                todoInput.value = '';
            }
        });

        // Initial load of to-do items
        async function loadInitialTodos() {
            try {
                const todos = await window.wintoolAPI.invoke(pluginId, 'getTodos');
                renderTodos(todos);
            } catch (err) {
                console.error(`${pluginId}: Error loading initial todos:`, err);
                todoList.innerHTML = '<li>Error loading tasks.</li>';
            }
        }
        loadInitialTodos();
    }

    console.log(`${pluginId} initialized successfully!`);

    // --- Finalization ---
    // This function must be called to let WinTool know that your plugin's tab has finished loading.
    if (window.markTabAsReady) {
        window.markTabAsReady(pluginId);
    }

}, 0);