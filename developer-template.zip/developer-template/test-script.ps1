# This is a test script for the wintoolAPI.runPluginScript function.
# It returns a string with some system information.

$os = Get-ComputerInfo | Select-Object -ExpandProperty OsName
$psVersion = $PSVersionTable.PSVersion

"Hello from PowerShell! You are running $os with PowerShell version $psVersion."
