const { shell } = require('electron');
const path = require('path');

module.exports = {
    initialize: (api) => {
        /**
         * Registers a handler to safely launch a file, application, or URL.
         * It uses Electron's shell.openPath() for local files/apps and
         * shell.openExternal() for web URLs.
         */
        api.registerHandler('launch-item', async ({ type, itemPath }) => {
            try {
                if (!type || !itemPath) {
                    throw new Error('Invalid arguments: type and itemPath are required.');
                }

                if (type === 'url') {
                    let fullUrl = itemPath;
                    // If the URL doesn't start with a protocol, add https:// by default.
                    if (!/^https?:\/\//i.test(fullUrl)) {
                        fullUrl = 'https://' + fullUrl;
                    }
                    await shell.openExternal(fullUrl);
                    return { success: true };
                } else {
                    // It's a file, folder, or application on the local system
                    const openResult = await shell.openPath(path.resolve(itemPath));
                    if (openResult) {
                        // If openPath returns a non-empty string, it means an error occurred.
                        throw new Error(openResult);
                    }
                    return { success: true };
                }
            } catch (error) {
                console.error(`[Quick Launcher] Error launching item: ${itemPath}`, error);
                // Return a structured error to the frontend
                return { success: false, error: error.message };
            }
        });
    }
};
