// Defer execution to ensure all plugin elements are in the DOM.
setTimeout(() => {
    // --- Plugin Info ---
    const PLUGIN_ID = 'quick-launcher';

    // --- DOM Elements ---
    const addItemBtn = document.getElementById('add-item-btn');
    const launcherGrid = document.getElementById('launcher-grid');
    const modal = document.getElementById('item-modal');
    const modalTitle = document.getElementById('modal-title');
    const closeButton = document.querySelector('.close-button');
    const itemForm = document.getElementById('item-form');
    const itemIdInput = document.getElementById('item-id');
    const itemNameInput = document.getElementById('item-name');
    const itemTypeSelect = document.getElementById('item-type');
    const itemPathInput = document.getElementById('item-path');
    const browseBtn = document.getElementById('browse-btn');
    const deleteBtn = document.getElementById('delete-item-btn');

    // --- State ---
    let items = [];
    let editingItemId = null;

    // --- Functions ---

    /**
     * Renders all launcher items in the grid.
     */
    const renderItems = () => {
        launcherGrid.innerHTML = '';
        if (items.length === 0) {
            launcherGrid.innerHTML = '<div class="empty-grid-message"><p>No shortcuts yet!</p><p>Click "Add New Shortcut" to get started.</p></div>';
            return;
        }

        items.forEach(item => {
            const itemEl = document.createElement('div');
            itemEl.className = 'launcher-item';
            
            let iconClass = 'fas fa-file-alt'; // Default for file
            if (item.type === 'url') iconClass = 'fas fa-globe-americas';
            else if (item.type === 'app') iconClass = 'fas fa-desktop';
            else if (item.type === 'folder') iconClass = 'fas fa-folder-open';

            itemEl.innerHTML = `
                <div class="item-actions">
                    <button class="edit-item-btn" data-id="${item.id}"><i class="fas fa-pencil-alt"></i></button>
                </div>
                <div class="item-main-content" data-id="${item.id}">
                    <div class="item-icon"><i class="${iconClass}"></i></div>
                    <div class="item-name">${item.name}</div>
                </div>
            `;

            launcherGrid.appendChild(itemEl);
        });

        // Add event listeners after rendering
        launcherGrid.querySelectorAll('.item-main-content').forEach(el => {
            el.addEventListener('click', (e) => {
                const id = e.currentTarget.dataset.id;
                const item = items.find(i => i.id === id);
                if (item) launchItem(item);
            });
        });

        launcherGrid.querySelectorAll('.edit-item-btn').forEach(el => {
            el.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent launching
                const id = e.currentTarget.dataset.id;
                openModal(id);
            });
        });
    };

    /**
     * Loads items from plugin storage.
     */
    const loadItems = async () => {
        const storedItems = await window.wintoolAPI.storage.get(PLUGIN_ID, 'items');
        items = storedItems || [];
        renderItems();
    };

    /**
     * Saves all items to plugin storage.
     */
    const saveItems = async () => {
        await window.wintoolAPI.storage.set(PLUGIN_ID, 'items', items);
    };

    /**
     * Opens and configures the modal for adding or editing an item.
     * @param {string|null} id - The ID of the item to edit, or null to add a new one.
     */
    const openModal = (id = null) => {
        editingItemId = id;
        itemForm.reset();
        if (editingItemId) {
            const item = items.find(i => i.id === editingItemId);
            modalTitle.textContent = 'Edit Shortcut';
            itemIdInput.value = item.id;
            itemNameInput.value = item.name;
            itemTypeSelect.value = item.type;
            itemPathInput.value = item.path;
            deleteBtn.style.display = 'inline-block';
        } else {
            modalTitle.textContent = 'Add New Shortcut';
            deleteBtn.style.display = 'none';
        }
        modal.classList.add('visible');
    };

    /**
     * Closes the modal.
     */
    const closeModal = () => {
        modal.classList.remove('visible');
        editingItemId = null;
    };

    /**
     * Handles the form submission for saving an item.
     * @param {Event} e - The form submission event.
     */
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const newItem = {
            id: editingItemId || Date.now().toString(),
            name: itemNameInput.value,
            type: itemTypeSelect.value,
            path: itemPathInput.value,
        };

        if (editingItemId) {
            items = items.map(item => item.id === editingItemId ? newItem : item);
        } else {
            items.push(newItem);
        }
        
        await saveItems();
        renderItems();
        closeModal();
    };

    /**
     * Handles the deletion of an item.
     */
    const handleDelete = async () => {
        if (!editingItemId) return;
        items = items.filter(item => item.id !== editingItemId);
        await saveItems();
        renderItems();
        closeModal();
    };

    /**
     * Calls the backend to launch the specified item.
     * @param {object} item - The item object to launch.
     */
    const launchItem = async (item) => {
        const result = await window.wintoolAPI.invoke(PLUGIN_ID, 'launch-item', { type: item.type, itemPath: item.path });
        if (!result.success) {
            window.wintoolAPI.showNotification({
                type: 'error',
                title: 'Launch Error',
                body: `Failed to open "${item.name}". Reason: ${result.error}`
            });
        }
    };
    
    /**
     * Opens a file browser dialog to select a path.
     */
    const browseForPath = async () => {
        const type = itemTypeSelect.value;
        const dialogOptions = {
            // The 'app' type should also use the 'openFile' property.
            properties: type === 'folder' ? ['openDirectory'] : ['openFile'],
            title: `Select ${type.charAt(0).toUpperCase() + type.slice(1)}`
        };

        try {
            const result = await window.wintoolAPI.dialog.showOpenDialog(dialogOptions);

            // The custom plugin dialog API returns a specific structure.
            // It does not return `filePaths`. It returns a `file` object with a `path`.
            if (!result.canceled && result.file && result.file.path) {
                itemPathInput.value = result.file.path;
            }
        } catch (error) {
            console.error("Error opening file dialog:", error);
            window.wintoolAPI.showNotification({
                type: 'error',
                title: 'Dialog Error',
                body: 'Could not open the file browser.'
            });
        }
    };

    // --- Event Listeners ---
    addItemBtn.addEventListener('click', () => openModal());
    closeButton.addEventListener('click', closeModal);
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('visible')) {
            closeModal();
        }
    });
    itemForm.addEventListener('submit', handleFormSubmit);
    deleteBtn.addEventListener('click', handleDelete);
    browseBtn.addEventListener('click', browseForPath);
    itemTypeSelect.addEventListener('change', () => {
        browseBtn.style.display = itemTypeSelect.value === 'url' ? 'none' : 'inline-block';
    });


    // --- Initial Load ---
    loadItems();
    if (window.markTabAsReady) {
        window.markTabAsReady(PLUGIN_ID);
    }

}, 0);
