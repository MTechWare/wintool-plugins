// Defer execution to ensure all plugin elements are in the DOM.
setTimeout(() => {
    // --- DOM Elements ---
    const daysEl = document.getElementById('days');
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');
    const lastBootTimeEl = document.getElementById('last-boot-time');
    const button = document.getElementById('refresh-uptime-btn');

    // --- Functions ---
    const refreshData = () => {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-sync-alt fa-spin"></i> Refreshing...';
        
        window.wintoolAPI.getSystemInfo('time')
            .then(time => {
                if (!time || typeof time.uptime === 'undefined') throw new Error('Invalid data');
                const bootTime = new Date(Date.now() - (time.uptime * 1000));
                lastBootTimeEl.textContent = bootTime.toLocaleString();

                const uptime = time.uptime;
                daysEl.textContent = String(Math.floor(uptime / 86400)).padStart(2, '0');
                hoursEl.textContent = String(Math.floor((uptime % 86400) / 3600)).padStart(2, '0');
                minutesEl.textContent = String(Math.floor((uptime % 3600) / 60)).padStart(2, '0');
                secondsEl.textContent = String(Math.floor(uptime % 60)).padStart(2, '0');
            })
            .catch(err => {
                console.error("Uptime fetch error:", err);
                [daysEl, hoursEl, minutesEl, secondsEl].forEach(el => el.textContent = 'ERR');
                lastBootTimeEl.textContent = 'Error';
            })
            .finally(() => {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
            });
    };

    // --- Event Listeners ---
    button.addEventListener('click', refreshData);

    // --- Initial Load ---
    refreshData();

    if (window.markTabAsReady) {
        window.markTabAsReady('system-uptime');
    }
}, 0);
